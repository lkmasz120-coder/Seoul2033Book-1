package com.seoul2033.book;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    JSONArray data = new JSONArray();
    LinearLayout list;
    EditText search;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadData();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24);
        TextView title = new TextView(this); title.setText("서울 2033 북"); title.setTextSize(26); title.setPadding(0,0,0,16); root.addView(title);
        search = new EditText(this); search.setHint("인카운터 / 가젯 검색"); root.addView(search, new LinearLayout.LayoutParams(-1,-2));
        Button overlay = new Button(this); overlay.setText("게임 위에 공략창 띄우기"); root.addView(overlay);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); ScrollView sv = new ScrollView(this); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        search.setOnEditorActionListener((v,a,e)->{render(search.getText().toString()); return true;});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int af){} public void onTextChanged(CharSequence s,int st,int b,int c){render(s.toString());} public void afterTextChanged(android.text.Editable e){}});
        overlay.setOnClickListener(v -> { if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));} else startService(new Intent(this,OverlayService.class)); });
        setContentView(root); render("");
    }
    void loadData(){try(InputStream in=getAssets().open("data.json")){byte[] x=new byte[in.available()];in.read(x);data=new JSONArray(new String(x,StandardCharsets.UTF_8));}catch(Exception ignored){}}
    void render(String q){ list.removeAllViews(); q=q.toLowerCase(); try{for(int i=0;i<data.length();i++){JSONObject o=data.getJSONObject(i); String all=(o.optString("name")+" "+o.optString("tags")+" "+o.optString("body")).toLowerCase(); if(q.isEmpty()||all.contains(q)) addCard(o);}}catch(Exception ignored){} }
    void addCard(JSONObject o){TextView t=new TextView(this); t.setText("["+o.optString("type")+"] "+o.optString("name")+"\n"+o.optString("body")); t.setTextSize(16); t.setPadding(18,18,18,18); t.setGravity(Gravity.START); t.setBackgroundResource(android.R.drawable.dialog_holo_light_frame); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); list.addView(t,p);}
}
