package com.seoul2033.book;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    WindowManager wm; View box;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent i,int flags,int id){ show(); return START_STICKY; }
    void show(){ if(box!=null)return; wm=(WindowManager)getSystemService(WINDOW_SERVICE); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(18,12,18,18); l.setBackgroundColor(Color.WHITE); TextView title=new TextView(this); title.setText("서울 2033 북   ✕"); title.setTextSize(18); title.setOnClickListener(v->stopSelf()); l.addView(title); EditText e=new EditText(this); e.setHint("검색"); l.addView(e); TextView info=new TextView(this); info.setText("메인 앱에서 공략을 검색하세요.\n이 창은 게임 위에 표시되는 빠른 실행용입니다."); info.setPadding(0,12,0,0); l.addView(info); box=l; int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; WindowManager.LayoutParams p=new WindowManager.LayoutParams(700,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP|Gravity.END; p.y=120; wm.addView(box,p); }
    @Override public void onDestroy(){if(box!=null)wm.removeView(box);box=null;super.onDestroy();}
}
